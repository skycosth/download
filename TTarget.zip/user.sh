#!/bin/sh
 # MeowMeow 
 MEOW() {
  am start -a android.intent.action.MAIN -e mona "$@" -n meow.helper/.MainActivity >> /dev/null
  sleep 0.5
}

 # Check if target.txt exists
 if [ ! -f /data/adb/tricky_store/target.txt ]; then
 MEOW "----------------------------------------------------"
 MEOW "target.txt not found!"
 MEOW "Please install tricky store module first"
 # Redirect TrickyStore Release Source
 nohup am start -a android.intent.action.VIEW -d https://github.com/5ec1cff/TrickyStore/releases >/dev/null 2>&1 &
 abort "----------------------------------------------------"
 fi

 # Create the directory for target file if it doesn't exist
 mkdir -p /data/adb/tricky_store

 # Remove the target.txt file if it exists
 if [ -f /data/adb/tricky_store/target.txt ]; then
 rm /data/adb/tricky_store/target.txt
 fi

 # Add the package names to the target file
 MEOW "🎯Retrieving user app packages"
 echo "android" >> /data/adb/tricky_store/target.txt
 echo "com.android.vending!" >> /data/adb/tricky_store/target.txt
 echo "com.google.android.gms!" >> /data/adb/tricky_store/target.txt
 echo "com.reveny.nativecheck!" >> /data/adb/tricky_store/target.txt
 echo "io.github.vvb2060.keyattestation!" >> /data/adb/tricky_store/target.txt
 echo "io.github.vvb2060.mahoshojo" >> /data/adb/tricky_store/target.txt
 echo "icu.nullptr.nativetest" >> /data/adb/tricky_store/target.txt
 sleep 2
 pm list packages -3 | cut -d ":" -f 2 | sed 's/$/!'/ >> /data/adb/tricky_store/target.txt
 sleep 2

 # Display the result
 MEOW "🤩Here are the updated packages in target.txt:"
 echo " "
 cat /data/adb/tricky_store/target.txt
 sleep 7
 exit 0
# end of file