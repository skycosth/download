# MeowMeow 
MEOW() {
  am start -a android.intent.action.MAIN -e mona "$@" -n meow.helper/.MainActivity >> /dev/null
  sleep 0.5
}

# Check for volume key
CheckKey() {
while true; do
  key_code=$(getevent -qlc 1 | grep "KEY_" | awk '{print $3}')
  if [ -n "$key_code" ]; then
    echo "$key_code"
    sleep 1
    break
  fi
  sleep 0.1
done
}

# Handle Options based on key pressed
OPT() {
while true; do
  key=$(CheckKey)
  case $key in
    KEY_VOLUMEDOWN)
      return 0
      ;;
    KEY_VOLUMEUP)
      return 1
      ;;
    *)
      echo "❌ Invalid Key! Try Again. Key pressed: $key"
      ;;
  esac
done
}

# Toggle Services
MEOW " Press Volume  ➕  /  ➖   Button To Decide👾"
echo " "
echo "🗣️ Alright Buddy, What do you want?"
echo "══════════════════════════════════"
sleep 1
echo " "
echo " "
echo " [ 1 ] ADD ALL APPS "
echo " "
echo "- this includes both system apps & user apps"
echo " "
echo " "
echo " [ 2 ] ADD USER APPS ONLY "
echo " "
echo "- this includes only those app which you've installed manually"
echo " "
echo " "
echo " "
echo " Vol➕ All apps | Vol➖ Installed apps only"
OPT
if [ $? -eq 1 ]; then
. /data/adb/modules/Ttarget/systemuser.sh
MEOW "Adding ALL APPS into 🎯Target list"
else
. /data/adb/modules/Ttarget/user.sh
MEOW "Adding only USER APPS into 🎯Target list"
fi